
How to use
1) Upload to Netlify as a new site.
2) Add environment variable GCAL_WEBHOOK_URL with your Apps Script Web App URL (the /exec link).
3) Deploy. Test the booking form.
