
barbariska-emerald-rose
- Emerald + light pink + chocolate + beige palette, high contrast
- Booking with 12h picker (AM/PM) → 24h hidden value
- Restoration calculators (Kitchen min $800, Bathtub, Furniture/Door)
- Before/After slider gallery (replace images in /images)
- Netlify Forms + function relay to Apps Script via GCAL_WEBHOOK_URL
- Service Area dropdown with LA/Irvine/OC + nearby cities
